"""Notification system utilities package"""
