import requests
import json
import os
from typing import List, Dict
import time

class ExpoClient:
    """Expo Push Notification 클라이언트"""
    
    def __init__(self):
        self.expo_url = 'https://exp.host/--/api/v2/push/send'
        self.access_token = os.environ.get('EXPO_ACCESS_TOKEN')
        
        if not self.access_token:
            print("Warning: EXPO_ACCESS_TOKEN not found - using mock mode")
            self.mock_mode = True
        else:
            self.mock_mode = False
        
        self.headers = {
            'Accept': 'application/json',
            'Accept-encoding': 'gzip, deflate',
            'Content-Type': 'application/json'
        }
        
        if self.access_token:
            self.headers['Authorization'] = f'Bearer {self.access_token}'
    
    def send_notifications(self, notifications: List[Dict]) -> Dict:
        """개선된 배치 알림 발송 (Adaptive Rate Limiting + Exponential Backoff)"""
        
        if not notifications:
            return {'success': 0, 'errors': []}
        
        if self.mock_mode:
            print(f"Mock mode: Would send {len(notifications)} notifications")
            return {
                'success': len(notifications),
                'errors': [],
                'message': 'Mock send - no actual notifications sent'
            }
        
        # Expo 메시지 형식으로 변환
        expo_messages = self._convert_to_expo_format(notifications)
        
        # 개선된 배치 처리
        results = {'success': 0, 'errors': [], 'rate_limited': False}
        success_rate = 1.0  # 초기 성공률
        base_delay = 0.1    # 기본 대기 시간
        
        for i in range(0, len(expo_messages), 100):
            batch = expo_messages[i:i+100]
            
            # Exponential Backoff로 배치 전송
            batch_result = self._send_batch_with_retry(batch, max_retries=3)
            
            results['success'] += batch_result['success']
            results['errors'].extend(batch_result['errors'])
            
            # Rate limit 발생 여부 추적
            if batch_result.get('rate_limited'):
                results['rate_limited'] = True
            
            # 성공률 계산 및 적응형 대기 시간 조정
            if len(batch) > 0:
                batch_success_rate = batch_result['success'] / len(batch)
                success_rate = (success_rate * 0.8) + (batch_success_rate * 0.2)  # 이동 평균
            
            # 다음 배치를 위한 적응형 대기 시간
            if i + 100 < len(expo_messages):
                adaptive_delay = self._calculate_adaptive_delay(success_rate, base_delay, results['rate_limited'])
                print(f"Adaptive delay: {adaptive_delay:.3f}s (success_rate: {success_rate:.2f})")
                time.sleep(adaptive_delay)
        
        return results
    
    def _calculate_adaptive_delay(self, success_rate: float, base_delay: float, rate_limited: bool) -> float:
        """성공률 기반 적응형 대기 시간 계산"""
        
        # Rate limit 발생시 긴 대기
        if rate_limited:
            return base_delay * 10  # 1초
        
        # 성공률이 낮으면 대기 시간 증가
        if success_rate < 0.5:
            return base_delay * 5   # 500ms
        elif success_rate < 0.8:
            return base_delay * 2   # 200ms
        else:
            return base_delay       # 100ms (최적)
    
    def _convert_to_expo_format(self, notifications: List[Dict]) -> List[Dict]:
        """내부 알림 형식을 Expo 형식으로 변환"""
        expo_messages = []
        
        for notification in notifications:
            expo_message = {
                'to': notification['token'],
                'title': notification['title'],
                'body': notification['body'],
                'data': notification.get('data', {}),
                'priority': 'high' if notification.get('priority') == 'high' else 'normal'
            }
            
            # 선택적 필드들
            if notification.get('sound'):
                expo_message['sound'] = notification['sound']
            if notification.get('badge'):
                expo_message['badge'] = notification['badge']
                
            expo_messages.append(expo_message)
        
        return expo_messages
    
    def _send_batch_with_retry(self, batch: List[Dict], max_retries: int = 3) -> Dict:
        """Exponential Backoff가 적용된 배치 전송"""
        
        for attempt in range(max_retries + 1):
            try:
                result = self._send_batch(batch)
                
                # 성공시 rate_limited 플래그 추가
                result['rate_limited'] = False
                return result
                
            except RateLimitError as e:
                if attempt < max_retries:
                    # Exponential Backoff: 1초, 2초, 4초, 8초
                    wait_time = min(2 ** attempt, 8)
                    print(f"Rate limited (attempt {attempt + 1}/{max_retries + 1}), waiting {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    print(f"Max retries exceeded due to rate limiting")
                    return {
                        'success': 0, 
                        'errors': [{'error': 'Rate limit exceeded after retries'}],
                        'rate_limited': True
                    }
            
            except Exception as e:
                if attempt < max_retries:
                    # 일반 에러도 재시도 (네트워크 오류 등)
                    wait_time = min(2 ** attempt, 4)
                    print(f"Error sending batch (attempt {attempt + 1}/{max_retries + 1}): {e}")
                    print(f"Retrying in {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    print(f"Max retries exceeded due to error: {e}")
                    return {
                        'success': 0,
                        'errors': [{'error': str(e)}],
                        'rate_limited': False
                    }
        
        # 이 지점에 도달하면 안 됨
        return {'success': 0, 'errors': [{'error': 'Unexpected retry loop exit'}], 'rate_limited': False}
    
    def _send_batch(self, batch: List[Dict]) -> Dict:
        """배치 발송"""
        try:
            response = requests.post(
                self.expo_url, 
                json=batch, 
                headers=self.headers,
                timeout=30
            )
            
            if response.status_code == 200:
                response_data = response.json()
                receipts = response_data.get('data', [])
                
                success_count = 0
                errors = []
                
                for i, receipt in enumerate(receipts):
                    if receipt.get('status') == 'ok':
                        success_count += 1
                    else:
                        error_info = {
                            'token': batch[i]['to'],
                            'error': receipt.get('message', 'Unknown error'),
                            'details': receipt.get('details', {})
                        }
                        errors.append(error_info)
                        
                        # 무효한 토큰 처리
                        if receipt.get('details', {}).get('error') == 'DeviceNotRegistered':
                            self._handle_invalid_token(batch[i]['to'])
                
                return {'success': success_count, 'errors': errors}
            
            elif response.status_code == 429:
                # Rate limit 에러
                raise RateLimitError("Expo rate limit exceeded")
            else:
                raise Exception(f"Expo API error: {response.status_code} - {response.text}")
                
        except requests.RequestException as e:
            print(f"Network error sending batch: {e}")
            raise Exception(f"Network error: {e}")
    
    def _handle_invalid_token(self, token: str):
        """무효한 토큰 처리"""
        print(f"Invalid token detected: {token[:20]}...")
        # TODO: Spring Boot 저장소에서 토큰 제거 로직 추가 가능

class RateLimitError(Exception):
    """Rate limit 예외"""
    pass

def send_immediate_notifications(notifications: List[Dict]) -> Dict:
    """즉시 알림 발송"""
    expo_client = ExpoClient()
    return expo_client.send_notifications(notifications)