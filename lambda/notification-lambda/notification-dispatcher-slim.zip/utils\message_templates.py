from typing import Dict, List, Any
import time

def get_message_template(message_type: str, message_data: Dict[str, Any]) -> Dict[str, Any]:
    """메시지 타입별 템플릿 반환"""
    
    templates = {
        'order_confirmed': {
            'title': '주문 확정',
            'body': f"주문번호 {message_data.get('orderId', '')}가 확정되었습니다.",
            'data': {
                'orderId': message_data.get('orderId'),
                'action': 'view_order',
                'type': 'order_confirmed'
            },
            'priority': 'high'
        },
        
        'order_shipped': {
            'title': '배송 시작',
            'body': '주문하신 상품이 배송을 시작했습니다.',
            'data': {
                'orderId': message_data.get('orderId'),
                'trackingNumber': message_data.get('trackingNumber'),
                'action': 'track_order',
                'type': 'order_shipped'
            },
            'priority': 'normal'
        },
        
        'order_delivered': {
            'title': '배송 완료',
            'body': '주문하신 상품이 배송 완료되었습니다.',
            'data': {
                'orderId': message_data.get('orderId'),
                'action': 'confirm_delivery',
                'type': 'order_delivered'
            },
            'priority': 'normal'
        },
        
        'payment_failed': {
            'title': '결제 실패',
            'body': '결제 처리 중 문제가 발생했습니다. 확인해주세요.',
            'data': {
                'orderId': message_data.get('orderId'),
                'action': 'retry_payment',
                'type': 'payment_failed'
            },
            'priority': 'high'
        },
        
        'promotion': {
            'title': message_data.get('title', '특별 혜택'),
            'body': message_data.get('message', '새로운 프로모션이 있습니다!'),
            'data': {
                'promotionId': message_data.get('promotionId'),
                'action': 'view_promotion',
                'type': 'promotion'
            },
            'priority': 'normal'
        },
        
        'system_notice': {
            'title': message_data.get('title', '시스템 공지'),
            'body': message_data.get('message', '시스템 공지사항이 있습니다.'),
            'data': {
                'noticeId': message_data.get('noticeId'),
                'action': 'view_notice',
                'type': 'system_notice'
            },
            'priority': 'normal'
        }
    }
    
    # 기본 템플릿
    default_template = {
        'title': '알림',
        'body': message_data.get('message', '새로운 알림이 있습니다.'),
        'data': {**message_data, 'type': message_type},
        'priority': 'normal'
    }
    
    return templates.get(message_type, default_template)

def create_notifications(user_id: str, push_tokens: List[Dict], 
                        message_type: str, message_data: Dict) -> List[Dict]:
    """사용자별 알림 메시지들 생성"""
    
    template = get_message_template(message_type, message_data)
    
    notifications = []
    
    for token_info in push_tokens:
        notification = {
            'userId': user_id,
            'token': token_info['token'],
            'platform': token_info.get('platform', 'unknown'),
            'deviceId': token_info.get('deviceId', ''),
            'title': template['title'],
            'body': template['body'],
            'data': {
                **template['data'],
                'userId': user_id,
                'deviceId': token_info.get('deviceId', '')
            },
            'priority': template.get('priority', 'normal'),
            'createdAt': int(time.time() * 1000),
            'attempts': 0
        }
        
        notifications.append(notification)
    
    return notifications