import redis
import os
import json
import time
import hashlib
from typing import Optional, List, Dict

class ValkeyClient:
    """Valkey 클라이언트 싱글톤"""
    
    _instance: Optional[redis.Redis] = None
    
    @classmethod
    def get_client(cls) -> redis.Redis:
        if cls._instance is None:
            cls._instance = redis.Redis(
                host=os.environ['VALKEY_HOST'],
                port=int(os.environ.get('VALKEY_PORT', 6379)),
                decode_responses=True,
                socket_connect_timeout=15,  # 5초 → 15초로 증가
                socket_timeout=15,         # 5초 → 15초로 증가
                retry_on_timeout=True,
                health_check_interval=30,
                max_connections=20
            )
            
            # 연결 테스트
            try:
                cls._instance.ping()
                print("Valkey connection established")
            except redis.ConnectionError as e:
                print(f"Valkey connection failed: {e}")
                raise
                
        return cls._instance
    
    @classmethod
    def close(cls):
        if cls._instance:
            cls._instance.close()
            cls._instance = None

def get_user_push_tokens(user_id: str) -> List[Dict]:
    """Spring Boot에서 저장한 토큰 조회 - 간단한 JSON 파싱 방식"""
    
    valkey = ValkeyClient.get_client()
    
    # user_id를 int로 변환해서 키 생성
    try:
        user_id_int = int(user_id)
        index_key = f"userTokenIndex:{user_id_int}"
        print(f"Looking up tokens for user_id: {user_id_int} using key: {index_key}")
        
        # 토큰 목록 가져오기 (SET 멤버)
        tokens = valkey.smembers(index_key)
        print(f"Found {len(tokens)} token references: {list(tokens)}")
        
        if not tokens:
            print(f"No tokens found for user {user_id_int}")
            
            # 디버깅: 실제 존재하는 키들 확인
            similar_keys = valkey.keys(f'userTokenIndex:*')
            print(f"Available userTokenIndex keys (first 10): {similar_keys[:10]}")
            
            return []
        
        result = []
        for token in tokens:
            # 토큰에서 불필요한 따옴표 제거
            clean_token = token.strip('"\'')
            token_key = f"notificationToken:{clean_token}"
            print(f"Fetching token details from key: {token_key}")
            print(f"Original token: {token} -> Cleaned token: {clean_token}")
            
            # 토큰 상세 정보 가져오기 (JSON 문자열)
            raw = valkey.get(token_key)
            if raw:
                try:
                    obj = json.loads(raw)  # {"@class":"...", "userId":5, "token":"abc123xyz"}
                    print(f"Parsed token object: {obj}")
                    
                    # 필수 필드 확인
                    if obj.get('userId') and obj.get('token'):
                        # Lambda에서 사용할 형태로 변환
                        token_info = {
                            'userId': str(obj['userId']),
                            'token': obj['token'],
                            'createdAt': obj.get('createdAt'),
                            'updatedAt': obj.get('updatedAt')
                        }
                        result.append(token_info)
                        print(f"Added valid token for user {obj['userId']}")
                    else:
                        print(f"Token object missing required fields: {obj}")
                        
                except json.JSONDecodeError as e:
                    print(f"Failed to parse token JSON: {e}")
                    print(f"Raw data: {raw[:100]}...")
            else:
                print(f"No data found for token key: {token_key}")
        
        print(f"Successfully retrieved {len(result)} valid tokens")
        return result
        
    except ValueError:
        print(f"Invalid user_id format: {user_id} (cannot convert to int)")
        return []
        
        valid_tokens = []
        invalid_tokens = []
        
        for token in tokens:
            token_key = f'notificationToken:{token}'
            
            try:
                # Jackson 직렬화된 NotificationToken 객체 조회
                token_data = valkey.get(token_key)
                
                if token_data:
                    # JSON 파싱
                    token_obj = json.loads(token_data)
                    
                    # 필수 필드 검증
                    if token_obj.get('userId') and token_obj.get('token'):
                        # Expo 토큰 형식 검증
                        if is_valid_expo_token(token):
                            valid_tokens.append({
                                'token': token,
                                'userId': str(token_obj['userId']),
                                'springBootUserId': token_obj['userId']
                            })
                        else:
                            print(f"Invalid Expo token format: {token[:20]}...")
                            invalid_tokens.append(token)
                    else:
                        print(f"Missing required fields in token data")
                        invalid_tokens.append(token)
                else:
                    print(f"Token data not found for {token}")
                    invalid_tokens.append(token)
                    
            except (json.JSONDecodeError, TypeError) as e:
                print(f"Error parsing token data for {token}: {e}")
                invalid_tokens.append(token)
        
        # 무효한 토큰들 정리
        if invalid_tokens:
            cleanup_invalid_tokens(valkey, index_key, invalid_tokens)
        
        print(f"Found {len(valid_tokens)} valid tokens for user {user_id}")
        return valid_tokens
        
    except Exception as e:
        print(f"Error getting tokens for user {user_id}: {e}")
        return []

def is_valid_expo_token(token: str) -> bool:
    """Expo 토큰 형식 검증"""
    return (token.startswith('ExponentPushToken[') and token.endswith(']')) or \
           (token.startswith('ExpoPushToken[') and token.endswith(']'))


def cleanup_invalid_tokens(valkey: redis.Redis, index_key: str, invalid_tokens: List[str]):
    """무효한 토큰들 정리"""
    pipe = valkey.pipeline()
    for invalid_token in invalid_tokens:
        pipe.srem(index_key, invalid_token)
        pipe.delete(f'notificationToken:{invalid_token}')
    pipe.execute()
    print(f"Cleaned up {len(invalid_tokens)} invalid tokens")

def create_message_hash(user_id: str, message_type: str, message_data: Dict) -> str:
    """메시지 고유 해시 생성 (중복 방지용)"""
    # 중복 방지를 위한 핵심 요소들로 해시 생성
    key_elements = {
        'userId': str(user_id),
        'messageType': message_type,
        'orderId': message_data.get('orderId', ''),
        'eventId': message_data.get('eventId', ''),
        # 메시지 내용 자체는 제외 (같은 주문의 상태 변경 알림은 중복 방지)
    }
    
    # 빈 값 제거 후 정렬된 키로 해시 생성
    filtered_elements = {k: v for k, v in key_elements.items() if v}
    key_string = json.dumps(filtered_elements, sort_keys=True, separators=(',', ':'))
    
    return hashlib.md5(key_string.encode('utf-8')).hexdigest()

def check_duplicate_notification(message_hash: str, ttl_minutes: int = 60) -> bool:
    """중복 알림 체크 및 기록 (TTL 기반)
    
    Args:
        message_hash: 메시지 고유 해시
        ttl_minutes: 중복 방지 시간 (분)
    
    Returns:
        bool: True면 중복(이미 전송됨), False면 신규
    """
    valkey = ValkeyClient.get_client()
    duplicate_key = f"notification_sent:{message_hash}"
    
    try:
        # 이미 전송된 알림인지 확인
        if valkey.exists(duplicate_key):
            print(f"Duplicate notification detected: {message_hash}")
            return True
        
        # 전송 기록 저장 (TTL과 함께)
        valkey.setex(duplicate_key, ttl_minutes * 60, json.dumps({
            'hash': message_hash,
            'sentAt': time.time(),
            'ttl': ttl_minutes
        }))
        
        print(f"New notification registered: {message_hash} (TTL: {ttl_minutes}min)")
        return False
        
    except Exception as e:
        print(f"Error checking duplicate notification: {e}")
        # 에러 시 중복이 아닌 것으로 처리 (안전한 쪽으로)
        return False

def get_duplicate_prevention_config(message_type: str) -> Dict[str, int]:
    """메시지 유형별 중복 방지 설정
    
    Returns:
        Dict: {'ttl_minutes': int, 'enabled': bool}
    """
    # 메시지 유형별 다른 TTL 정책
    DUPLICATE_POLICIES = {
        'order_confirmed': {'ttl_minutes': 60, 'enabled': True},     # 1시간
        'order_cancelled': {'ttl_minutes': 30, 'enabled': True},     # 30분
        'payment_completed': {'ttl_minutes': 120, 'enabled': True},  # 2시간
        'payment_failed': {'ttl_minutes': 30, 'enabled': True},      # 30분
        'delivery_started': {'ttl_minutes': 60, 'enabled': True},    # 1시간
        'delivery_completed': {'ttl_minutes': 180, 'enabled': True}, # 3시간
        'security_alert': {'ttl_minutes': 15, 'enabled': True},      # 15분 (보안은 짧게)
        'promotion': {'ttl_minutes': 1440, 'enabled': True},         # 24시간 (프로모션은 길게)
        'system_maintenance': {'ttl_minutes': 360, 'enabled': True}, # 6시간
    }
    
    return DUPLICATE_POLICIES.get(message_type, {
        'ttl_minutes': 60,  # 기본 1시간
        'enabled': True
    })

def cleanup_expired_duplicates():
    """만료된 중복 방지 기록들 정리 (Worker에서 주기적 호출용)"""
    valkey = ValkeyClient.get_client()
    
    try:
        # notification_sent:* 패턴의 키들 스캔
        pattern = "notification_sent:*"
        cursor = 0
        cleaned_count = 0
        
        while True:
            cursor, keys = valkey.scan(cursor, match=pattern, count=100)
            
            for key in keys:
                # TTL 확인해서 만료된 것들 삭제
                ttl = valkey.ttl(key)
                if ttl == -1:  # TTL이 설정되지 않은 경우
                    valkey.delete(key)
                    cleaned_count += 1
                elif ttl == -2:  # 이미 만료된 경우
                    cleaned_count += 1
            
            if cursor == 0:
                break
        
        if cleaned_count > 0:
            print(f"Cleaned up {cleaned_count} expired duplicate prevention records")
            
    except Exception as e:
        print(f"Error cleaning up expired duplicates: {e}")

def queue_notifications(notifications: List[Dict], priority: str = 'normal', ttl_hours: int = 24):
    """알림들을 TTL과 함께 큐에 추가 (ZSET 기반)"""
    valkey = ValkeyClient.get_client()
    queue_key = f'notification_queue:{priority}'
    
    try:
        # TTL을 고려한 스코어 기반 저장 (ZSET 사용)
        expire_time = time.time() + (ttl_hours * 3600)
        current_time = time.time()
        
        pipe = valkey.pipeline()
        
        for notification in notifications:
            # 재시도 횟수 및 TTL 정보 추가
            notification['retry_count'] = 0
            notification['max_retries'] = 3
            notification['created_at'] = current_time
            notification['expires_at'] = expire_time
            notification['priority'] = priority
            
            notification_json = json.dumps(notification)
            # 스코어는 생성 시간 사용 (FIFO 순서)
            pipe.zadd(queue_key, {notification_json: current_time})
        
        # 큐 전체에 TTL 설정 (최대 보관 기간)
        pipe.expire(queue_key, ttl_hours * 3600 + 3600)  # +1시간 여유
        pipe.execute()
            
        print(f"Queued {len(notifications)} notifications to {queue_key} with {ttl_hours}h TTL")
        
    except Exception as e:
        print(f"Failed to queue notifications: {e}")
        raise

def get_batch_from_queue(queue_key: str, batch_size: int = 10) -> List[Dict]:
    """TTL을 고려한 큐에서 배치 조회 (ZSET 기반)"""
    valkey = ValkeyClient.get_client()
    notifications = []
    current_time = time.time()
    
    try:
        # 1. 만료된 알림들 먼저 정리
        cleanup_expired_notifications(queue_key)
        
        # 2. 가장 오래된 알림부터 배치 크기만큼 조회
        items = valkey.zrange(queue_key, 0, batch_size - 1, withscores=True)
        
        if not items:
            return []
        
        # 3. 조회된 아이템들을 큐에서 제거하고 파싱
        pipe = valkey.pipeline()
        for item_json, score in items:
            pipe.zrem(queue_key, item_json)
        pipe.execute()
        
        # 4. JSON 파싱 및 TTL 검증
        for item_json, score in items:
            try:
                notification = json.loads(item_json)
                
                # TTL 체크
                if notification.get('expires_at', float('inf')) > current_time:
                    notifications.append(notification)
                else:
                    print(f"Skipped expired notification: {notification.get('title', 'Unknown')}")
                    
            except json.JSONDecodeError as e:
                print(f"Error parsing queue item: {e}")
        
        print(f"Retrieved {len(notifications)} valid notifications from {queue_key}")
        return notifications
        
    except Exception as e:
        print(f"Error getting batch from queue {queue_key}: {e}")
        return []

def get_queue_size(queue_key: str) -> int:
    """큐 크기 조회 (ZSET 기반)"""
    valkey = ValkeyClient.get_client()
    return valkey.zcard(queue_key)

def acquire_processing_lock(queue_key: str, ttl_seconds: int = 900) -> bool:
    """처리 락 획득"""
    valkey = ValkeyClient.get_client()
    lock_key = f'processing_lock:{queue_key}'
    lock_value = f'{os.environ.get("AWS_LAMBDA_LOG_STREAM_NAME", "unknown")}-{int(time.time())}'
    
    acquired = valkey.set(lock_key, lock_value, px=ttl_seconds * 1000, nx=True)
    if acquired:
        print(f"Acquired processing lock for {queue_key}")
    else:
        print(f"Failed to acquire lock for {queue_key} - another process is working")
    
    return bool(acquired)

def release_processing_lock(queue_key: str):
    """처리 락 해제"""
    valkey = ValkeyClient.get_client()
    lock_key = f'processing_lock:{queue_key}'
    valkey.delete(lock_key)
    print(f"Released processing lock for {queue_key}")

def cleanup_expired_notifications(queue_key: str):
    """만료된 알림들 정리"""
    valkey = ValkeyClient.get_client()
    current_time = time.time()
    
    try:
        # 모든 알림 조회
        items = valkey.zrange(queue_key, 0, -1, withscores=True)
        expired_items = []
        
        for item_json, score in items:
            try:
                notification = json.loads(item_json)
                expires_at = notification.get('expires_at', float('inf'))
                
                if expires_at <= current_time:
                    expired_items.append(item_json)
                    
            except json.JSONDecodeError:
                # 파싱 실패한 아이템도 제거
                expired_items.append(item_json)
        
        # 만료된 아이템들 제거
        if expired_items:
            pipe = valkey.pipeline()
            for item in expired_items:
                pipe.zrem(queue_key, item)
            pipe.execute()
            print(f"Cleaned up {len(expired_items)} expired notifications from {queue_key}")
            
    except Exception as e:
        print(f"Error cleaning up expired notifications: {e}")

def requeue_failed_notification(notification: Dict, reason: str = "retry"):
    """실패한 알림을 재시도 큐에 추가"""
    try:
        retry_count = notification.get('retry_count', 0) + 1
        max_retries = notification.get('max_retries', 3)
        
        if retry_count > max_retries:
            print(f"Max retries ({max_retries}) exceeded for notification: {notification.get('title', 'Unknown')}")
            # 최종 실패 큐로 이동
            send_to_dead_letter_queue(notification, f"Max retries exceeded: {reason}")
            return False
        
        # 재시도 횟수 증가
        notification['retry_count'] = retry_count
        notification['last_error'] = reason
        notification['retry_at'] = time.time()
        
        # 지수적 백오프 적용 (1초, 4초, 16초)
        delay_seconds = 4 ** (retry_count - 1)
        retry_time = time.time() + delay_seconds
        
        # 재시도 큐에 추가 (지연된 스코어 사용)
        valkey = ValkeyClient.get_client()
        retry_queue_key = f"notification_queue:retry"
        
        notification_json = json.dumps(notification)
        valkey.zadd(retry_queue_key, {notification_json: retry_time})
        valkey.expire(retry_queue_key, 86400)  # 24시간 TTL
        
        print(f"Requeued notification (attempt {retry_count}/{max_retries}) with {delay_seconds}s delay")
        return True
        
    except Exception as e:
        print(f"Error requeuing notification: {e}")
        return False

# DLQ 기능 - SNS 미사용으로 주석 처리
def send_to_dead_letter_queue(notification: Dict, reason: str):
    """최종 실패한 알림을 DLQ로 전송 - 현재 비활성화"""
    # SNS를 사용하지 않으므로 DLQ 기능 비활성화
    print(f"DLQ disabled: Would send notification to DLQ with reason: {reason}")
    return
    
    # try:
    #     valkey = ValkeyClient.get_client()
    #     dlq_key = "notification_queue:dlq"
    #     
    #     dlq_item = {
    #         **notification,
    #         'dlq_reason': reason,
    #         'dlq_timestamp': time.time(),
    #         'final_failure': True
    #     }
    #     
    #     dlq_json = json.dumps(dlq_item)
    #     valkey.zadd(dlq_key, {dlq_json: time.time()})
    #     valkey.expire(dlq_key, 7 * 86400)  # 7일 보관
    #     
    #     print(f"Sent notification to DLQ: {reason}")
    #     
    # except Exception as e:
    #     print(f"Error sending to DLQ: {e}")

def process_retry_queue():
    """재시도 큐에서 준비된 알림들 처리"""
    valkey = ValkeyClient.get_client()
    retry_queue_key = "notification_queue:retry"
    current_time = time.time()
    
    try:
        # 재시도 시간이 된 알림들 조회
        ready_items = valkey.zrangebyscore(retry_queue_key, 0, current_time, withscores=True)
        
        if not ready_items:
            return []
        
        # 조회된 아이템들을 재시도 큐에서 제거
        pipe = valkey.pipeline()
        for item_json, score in ready_items:
            pipe.zrem(retry_queue_key, item_json)
        pipe.execute()
        
        # 일반 큐로 다시 이동
        notifications = []
        for item_json, score in ready_items:
            try:
                notification = json.loads(item_json)
                notifications.append(notification)
            except json.JSONDecodeError as e:
                print(f"Error parsing retry queue item: {e}")
        
        if notifications:
            # 우선순위 큐로 이동 (재시도는 높은 우선순위)
            queue_notifications(notifications, priority='high', ttl_hours=12)
            print(f"Moved {len(notifications)} notifications from retry queue to high priority queue")
        
        return notifications
        
    except Exception as e:
        print(f"Error processing retry queue: {e}")
        return []