import json
import os
import boto3
import time
from typing import Dict, Any, List

# AWS 클라이언트들
lambda_client = boto3.client('lambda')
cloudwatch = boto3.client('cloudwatch')

def lambda_handler(event, context):
    """
    Notification Dispatcher Lambda 메인 핸들러
    EventBridge에서 오는 알림 이벤트를 처리하여 사용자에게 푸시 알림 발송
    """
    
    request_id = context.aws_request_id
    start_time = time.time()
    
    print(f"[{request_id}] Dispatcher started - Event: {json.dumps(event, default=str)}")
    print(f"[{request_id}] Remaining time: {context.get_remaining_time_in_millis()}ms")
    
    try:
        # 환경변수 검증
        required_env_vars = ['VALKEY_HOST', 'WORKER_FUNCTION_NAME']
        missing_vars = [var for var in required_env_vars if not os.environ.get(var)]
        
        if missing_vars:
            error_msg = f"Missing environment variables: {missing_vars}"
            print(f"[{request_id}] {error_msg}")
            return create_error_response(400, error_msg)
        
        # EventBridge 이벤트 파싱
        detail = event.get('detail', {})
        user_id = detail.get('userId')
        message_type = detail.get('messageType')
        message_data = detail.get('messageData', {})
        
        # 입력 검증
        if not user_id or not message_type:
            error_msg = 'userId and messageType are required in event detail'
            print(f"[{request_id}] Validation error: {error_msg}")
            return create_error_response(400, error_msg)
        
        print(f"[{request_id}] Processing: user_id={user_id}, message_type={message_type}")
        
        # 중복 알림 방지 체크
        try:
            from utils.valkey_client import (
                create_message_hash, 
                check_duplicate_notification, 
                get_duplicate_prevention_config
            )
            
            # 중복 방지 설정 확인
            duplicate_config = get_duplicate_prevention_config(message_type)
            
            if duplicate_config['enabled']:
                # 메시지 해시 생성
                message_hash = create_message_hash(
                    user_id=str(user_id),
                    message_type=message_type,
                    message_data=message_data
                )
                
                # 중복 체크
                is_duplicate = check_duplicate_notification(
                    message_hash=message_hash,
                    ttl_minutes=duplicate_config['ttl_minutes']
                )
                
                if is_duplicate:
                    print(f"[{request_id}] Duplicate notification skipped: {message_hash}")
                    
                    # 중복 스킵 메트릭
                    send_cloudwatch_metrics([('DuplicateNotificationSkipped', 1)])
                    
                    return {
                        'statusCode': 200,
                        'headers': {'Content-Type': 'application/json'},
                        'body': json.dumps({
                            'message': 'Duplicate notification skipped',
                            'messageHash': message_hash,
                            'ttlMinutes': duplicate_config['ttl_minutes'],
                            'requestId': request_id,
                            'skipped': True
                        })
                    }
                
                print(f"[{request_id}] New notification approved: {message_hash} (TTL: {duplicate_config['ttl_minutes']}min)")
            else:
                print(f"[{request_id}] Duplicate prevention disabled for {message_type}")
                
        except Exception as e:
            print(f"[{request_id}] Duplicate check failed: {e}, proceeding with notification")
            # 중복 체크 실패시에도 알림은 계속 처리
        
        # 메인 처리 로직
        result = process_notification_request(
            request_id=request_id,
            user_id=str(user_id), 
            message_type=message_type, 
            message_data=message_data,
            context=context
        )
        
        # 성공 메트릭 전송
        processing_time = time.time() - start_time
        send_cloudwatch_metrics([
            ('DispatcherSuccess', 1),
            ('ProcessingTime', processing_time * 1000, 'Milliseconds')
        ])
        
        print(f"[{request_id}] Processing completed in {processing_time:.3f}s")
        
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({
                **result,
                'requestId': request_id,
                'processingTime': round(processing_time * 1000, 2)
            })
        }
        
    except Exception as e:
        processing_time = time.time() - start_time
        error_msg = f"Dispatcher error: {str(e)}"
        
        print(f"[{request_id}] {error_msg}")
        print(f"[{request_id}] Error type: {type(e).__name__}")
        
        # 에러 메트릭 전송
        send_cloudwatch_metrics([
            ('DispatcherError', 1),
            ('ErrorProcessingTime', processing_time * 1000, 'Milliseconds')
        ])
        
        return create_error_response(500, error_msg, request_id)

def process_notification_request(request_id: str, user_id: str, message_type: str, 
                               message_data: Dict, context) -> Dict[str, Any]:
    """알림 요청 처리 메인 로직"""
    
    try:
        print(f"[{request_id}] Starting notification processing for user {user_id}")
        
        # 1. Valkey 연결 및 Push tokens 조회
        try:
            from utils.valkey_client import get_user_push_tokens
            
            # 환경변수 확인 로그
            valkey_host = os.environ.get('VALKEY_HOST', 'NOT_SET')
            valkey_port = os.environ.get('VALKEY_PORT', 'NOT_SET')
            print(f"[{request_id}] Attempting Valkey connection: {valkey_host}:{valkey_port}")
            
            push_tokens = get_user_push_tokens(user_id)
            print(f"[{request_id}] Retrieved {len(push_tokens)} push tokens from Valkey")
            
        except ImportError as e:
            raise Exception(f"Failed to import valkey_client: {e}")
        except Exception as e:
            print(f"[{request_id}] Valkey connection failed: {type(e).__name__}: {str(e)}")
            print(f"[{request_id}] Valkey host: {os.environ.get('VALKEY_HOST', 'NOT_SET')}")
            print(f"[{request_id}] Valkey port: {os.environ.get('VALKEY_PORT', 'NOT_SET')}")
            
            # Valkey 연결 실패시에도 계속 처리 (Mock 토큰 사용)
            push_tokens = create_mock_tokens(user_id)
            print(f"[{request_id}] Using {len(push_tokens)} mock tokens due to Valkey error")
        
        if not push_tokens:
            message = f'No push tokens found for user {user_id}'
            print(f"[{request_id}] {message}")
            return {
                'message': message,
                'tokenCount': 0,
                'method': 'no_tokens'
            }
        
        # 2. 알림 메시지들 생성
        try:
            from utils.message_templates import create_notifications
            notifications = create_notifications(user_id, push_tokens, message_type, message_data)
            print(f"[{request_id}] Created {len(notifications)} notifications")
            
        except ImportError as e:
            raise Exception(f"Failed to import message_templates: {e}")
        except Exception as e:
            print(f"[{request_id}] Message creation error: {e}")
            # 기본 메시지로 폴백
            notifications = create_fallback_notifications(user_id, push_tokens, message_type, message_data)
            print(f"[{request_id}] Created {len(notifications)} fallback notifications")
        
        # 3. 처리 방식 결정 (즉시 vs 큐)
        processing_strategy = determine_processing_strategy(
            notifications, message_type, context.get_remaining_time_in_millis()
        )
        
        print(f"[{request_id}] Processing strategy: {processing_strategy}")
        
        if processing_strategy == 'immediate':
            return handle_immediate_processing(request_id, notifications)
        else:
            return handle_queue_processing(request_id, notifications, processing_strategy)
            
    except Exception as e:
        print(f"[{request_id}] Processing error: {e}")
        raise

def determine_processing_strategy(notifications: List[Dict], message_type: str, 
                                remaining_time_ms: int) -> str:
    """처리 방식 결정 로직"""
    
    # 시간이 부족하면 무조건 큐
    if remaining_time_ms < 10000:  # 10초 미만
        return 'queue_timeout'
    
    # 소량이면 즉시 처리 시도
    if len(notifications) <= 10:
        return 'immediate'
    
    # 긴급 메시지는 작은 배치로 즉시 처리
    high_priority_types = ['payment_failed', 'security_alert', 'order_confirmed']
    if message_type in high_priority_types and len(notifications) <= 50:
        return 'immediate'
    
    # 대량은 큐로
    if len(notifications) > 100:
        return 'queue_bulk'
    else:
        return 'queue_normal'

def handle_immediate_processing(request_id: str, notifications: List[Dict]) -> Dict[str, Any]:
    """즉시 처리 로직"""
    
    try:
        print(f"[{request_id}] Attempting immediate processing of {len(notifications)} notifications")
        
        try:
            from utils.expo_client import send_immediate_notifications, RateLimitError
        except ImportError as import_error:
            print(f"[{request_id}] Failed to import expo_client: {import_error}")
            return handle_queue_processing(request_id, notifications, 'queue_import_error')
        
        result = send_immediate_notifications(notifications)
        
        success_count = result.get('success', 0)
        error_count = len(result.get('errors', []))
        
        print(f"[{request_id}] Immediate send result: {success_count} success, {error_count} errors")
        
        # RDS에 결과 기록
        try:
            from utils.rds_client import record_notification_success, record_notification_failure
            
            # 성공한 알림들 기록
            if success_count > 0:
                error_tokens = set()
                for error in result.get('errors', []):
                    if 'token' in error:
                        error_tokens.add(error['token'])
                
                # 에러가 없는 알림들 = 성공한 알림들
                for notification in notifications:
                    if notification.get('token') not in error_tokens:
                        record_notification_success(notification, result)
            
            # 실패한 알림들 기록
            for error in result.get('errors', []):
                error_notification = next(
                    (n for n in notifications if n.get('token') == error.get('token')), 
                    error.get('notification', {})
                )
                record_notification_failure(error_notification, error.get('error', 'Unknown error'))
                
        except Exception as rds_error:
            print(f"[{request_id}] RDS recording failed: {rds_error}")
            # RDS 실패해도 메인 로직에는 영향 없음
        
        # 성공 메트릭
        send_cloudwatch_metrics([
            ('ImmediateSend', success_count),
            ('ImmediateSendErrors', error_count)
        ])
        
        return {
            'message': f'Sent {success_count} notifications immediately',
            'success': success_count,
            'errors': error_count,
            'method': 'immediate',
            'details': result.get('errors', [])[:5]  # 처음 5개 에러만
        }
        
    except Exception as e:
        # RateLimitError와 기타 예외를 모두 처리
        error_message = str(e)
        error_type = type(e).__name__
        
        if 'RateLimitError' in error_type or 'rate limit' in error_message.lower():
            print(f"[{request_id}] Rate limit hit during immediate send, switching to queue")
            return handle_queue_processing(request_id, notifications, 'queue_ratelimit')
        else:
            print(f"[{request_id}] Immediate send failed: {e}, switching to queue")
        return handle_queue_processing(request_id, notifications, 'queue_fallback')

def handle_queue_processing(request_id: str, notifications: List[Dict], 
                          reason: str) -> Dict[str, Any]:
    """큐 처리 로직"""
    
    try:
        # 우선순위 결정
        priority = determine_priority(reason, len(notifications))
        
        print(f"[{request_id}] Queuing {len(notifications)} notifications with {priority} priority")
        
        # 큐에 추가
        try:
            from utils.valkey_client import queue_notifications
            queue_notifications(notifications, priority)
            queue_success = True
            
        except Exception as e:
            print(f"[{request_id}] Queue storage failed: {e}")
            queue_success = False
        
        # Worker Lambda 호출
        worker_triggered = False
        if queue_success:
            try:
                trigger_worker_lambda(request_id, priority)
                worker_triggered = True
                
            except Exception as e:
                print(f"[{request_id}] Worker trigger failed: {e}")
        
        # 메트릭 전송
        send_cloudwatch_metrics([
            ('QueuedNotifications', len(notifications)),
            ('QueueSuccess' if queue_success else 'QueueFailure', 1),
            ('WorkerTriggered' if worker_triggered else 'WorkerTriggerFailed', 1)
        ])
        
        return {
            'message': f'{len(notifications)} notifications queued with {priority} priority',
            'count': len(notifications),
            'priority': priority,
            'method': 'queued',
            'reason': reason,
            'queueSuccess': queue_success,
            'workerTriggered': worker_triggered
        }
        
    except Exception as e:
        print(f"[{request_id}] Queue processing error: {e}")
        raise

def determine_priority(reason: str, notification_count: int) -> str:
    """우선순위 결정"""
    
    if reason in ['queue_timeout', 'queue_ratelimit']:
        return 'high'
    elif notification_count > 100:
        return 'bulk'
    else:
        return 'normal'

def trigger_worker_lambda(request_id: str, priority: str = 'normal'):
    """Worker Lambda 호출"""
    
    worker_function_name = os.environ.get('WORKER_FUNCTION_NAME', 'notification-worker')
    
    payload = {
        'queue': f'notification_queue:{priority}',
        'priority': priority,
        'triggerReason': 'dispatcher_request',
        'triggeredAt': int(time.time()),
        'dispatcherRequestId': request_id
    }
    
    try:
        response = lambda_client.invoke(
            FunctionName=worker_function_name,
            InvocationType='Event',  # 비동기 호출
            Payload=json.dumps(payload)
        )
        
        print(f"[{request_id}] Worker triggered successfully: {worker_function_name}")
        print(f"[{request_id}] Worker payload: {payload}")
        
        return True
        
    except Exception as e:
        print(f"[{request_id}] Failed to trigger worker: {e}")
        raise

def create_mock_tokens(user_id: str) -> List[Dict]:
    """Valkey 연결 실패시 Mock 토큰 생성 (테스트용)"""
    
    return [
        {
            'token': f'mock_expo_token_for_user_{user_id}',
            'userId': user_id
        }
    ]

def create_fallback_notifications(user_id: str, push_tokens: List[Dict], 
                                message_type: str, message_data: Dict) -> List[Dict]:
    """메시지 템플릿 실패시 폴백 알림 생성"""
    
    title = message_data.get('title', '알림')
    body = message_data.get('message', f'{message_type} 알림이 있습니다.')
    
    return [
        {
            'userId': user_id,
            'token': token_info['token'],
            'title': title,
            'body': body,
            'data': {
                'type': message_type,
                'userId': user_id,
                **message_data
            },
            'priority': 'normal',
            'createdAt': int(time.time() * 1000),
            'attempts': 0
        }
        for token_info in push_tokens
    ]

def send_cloudwatch_metrics(metrics: List[tuple]):
    """CloudWatch 메트릭 배치 전송"""
    
    try:
        metric_data = []
        
        for metric in metrics:
            if len(metric) == 2:
                name, value = metric
                unit = 'Count'
            else:
                name, value, unit = metric
                
            metric_data.append({
                'MetricName': name,
                'Value': value,
                'Unit': unit,
                'Timestamp': time.time()
            })
        
        if metric_data:
            cloudwatch.put_metric_data(
                Namespace='NotificationSystem/Dispatcher',
                MetricData=metric_data
            )
            
    except Exception as e:
        print(f"Failed to send CloudWatch metrics: {e}")

def create_error_response(status_code: int, error_message: str, request_id: str = None) -> Dict:
    """표준 에러 응답 생성"""
    
    response_body = {
        'error': error_message,
        'timestamp': int(time.time())
    }
    
    if request_id:
        response_body['requestId'] = request_id
    
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'X-Request-ID': request_id or 'unknown'
        },
        'body': json.dumps(response_body)
    }

# Lambda 실행시 필요한 전역 변수들
FUNCTION_VERSION = os.environ.get('AWS_LAMBDA_FUNCTION_VERSION', '$LATEST')
FUNCTION_NAME = os.environ.get('AWS_LAMBDA_FUNCTION_NAME', 'unknown')

print(f"Dispatcher Lambda initialized - Function: {FUNCTION_NAME}, Version: {FUNCTION_VERSION}")