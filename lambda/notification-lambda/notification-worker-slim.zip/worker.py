import json
import os
import boto3
import time
from typing import Dict, List

# 유틸리티 임포트
from utils.valkey_client import (
    ValkeyClient,
    get_batch_from_queue,
    get_queue_size,
    acquire_processing_lock,
    release_processing_lock,
    requeue_failed_notification,
    process_retry_queue,
    cleanup_expired_notifications,
    cleanup_expired_duplicates
)
from utils.expo_client import send_immediate_notifications, RateLimitError
from utils.rds_client import record_notification_success, record_notification_failure, record_notification_retry

# AWS 클라이언트
lambda_client = boto3.client('lambda')
cloudwatch = boto3.client('cloudwatch')

def lambda_handler(event, context):
    """
    Worker Lambda 메인 핸들러
    큐에서 알림들을 배치 처리
    """
    print(f"Worker received event: {json.dumps(event, default=str)}")
    
    try:
        # 이벤트에서 큐 정보 추출
        queue = event.get('queue', 'notification_queue:normal')
        priority = event.get('priority', 'normal')
        trigger_reason = event.get('triggerReason', 'unknown')
        
        print(f"Processing queue: {queue}, priority: {priority}, reason: {trigger_reason}")
        
        # 큐 처리
        result = process_notification_queue(queue)
        
        # 성공 메트릭
        send_metric('WorkerSuccess', 1)
        send_metric(f'ProcessedNotifications_{priority}', result['processed'])
        
        return {
            'statusCode': 200,
            'body': json.dumps(result)
        }
        
    except Exception as e:
        error_msg = f"Worker error: {str(e)}"
        print(error_msg)
        
        # 에러 메트릭
        send_metric('WorkerError', 1)
        
        return {
            'statusCode': 500,
            'body': json.dumps({'error': error_msg})
        }

def process_notification_queue(queue: str) -> Dict:
    """큐 처리 메인 로직"""
    
    # 처리 락 획득 (15분)
    if not acquire_processing_lock(queue, ttl_seconds=900):
        return {
            'message': 'Another worker is already processing this queue',
            'processed': 0,
            'skipped': True
        }
    
    try:
        return process_queue_with_lock(queue)
    finally:
        release_processing_lock(queue)

def process_queue_with_lock(queue: str) -> Dict:
    """TTL 및 재시도 로직이 적용된 큐 처리"""
    
    processed_count = 0
    error_count = 0
    retry_count = 0
    start_time = time.time()
    max_runtime = 14 * 60  # 14분 (Lambda 최대 실행시간 고려)
    
    # 1. 만료된 알림들 먼저 정리
    cleanup_expired_notifications(queue)
    
    # 중복 방지 기록 정리 (5분에 한 번 정도)
    import random
    if random.random() < 0.2:  # 20% 확률로 실행
        try:
            print("Running duplicate prevention cleanup...")
            cleanup_expired_duplicates()
        except Exception as e:
            print(f"Duplicate cleanup failed: {e}")
    
    # 2. 재시도 큐에서 준비된 알림들 처리
    retry_notifications = process_retry_queue()
    if retry_notifications:
        retry_count = len(retry_notifications)
        print(f"Processed {retry_count} notifications from retry queue")
    
    # 우선순위별 배치 크기 및 처리 간격 설정
    batch_config = get_batch_config_for_queue(queue)
    batch_size = batch_config['batch_size']
    processing_delay = batch_config['delay']
    
    print(f"Starting queue processing with batch_size={batch_size}, delay={processing_delay}ms")
    
    while time.time() - start_time < max_runtime:
        # 배치 조회 (TTL 체크 포함)
        notifications = get_batch_from_queue(queue, batch_size)
        
        if not notifications:
            print("Queue is empty, processing completed")
            break
        
        print(f"Processing batch of {len(notifications)} notifications")
        
        # 배치 처리 (개선된 재시도 로직)
        try:
            batch_result = process_notification_batch_with_retry(notifications)
            processed_count += batch_result['success']
            error_count += batch_result['failed']
            
        except RateLimitError:
            print("Rate limit hit, requeuing notifications and waiting")
            # 모든 알림을 재시도 큐로 (Rate limit은 일시적 실패)
            for notification in notifications:
                requeue_failed_notification(notification, "rate_limit_hit")
            time.sleep(5)  # 5초 대기
            break
            
        except Exception as e:
            print(f"Batch processing error: {e}")
            error_count += len(notifications)
            
            # 실패한 알림들을 재시도 큐로
            for notification in notifications:
                requeue_failed_notification(notification, f"batch_error: {str(e)}")
        
        # Rate limit 준수를 위한 대기
        if processing_delay > 0:
            time.sleep(processing_delay / 1000.0)  # ms -> seconds
    
    # 큐에 남은 아이템이 있으면 다음 Worker 호출
    remaining_items = get_queue_size(queue)
    
    if remaining_items > 0:
        print(f"Queue still has {remaining_items} items, triggering next worker")
        trigger_next_worker(queue)
    
    runtime = time.time() - start_time
    
    result = {
        'message': f'Processed {processed_count} notifications with {error_count} errors, {retry_count} retries',
        'processed': processed_count,
        'errors': error_count,
        'retries': retry_count,
        'runtime_seconds': round(runtime, 2),
        'remaining_items': remaining_items
    }
    
    print(f"Worker completed: {result}")
    return result

def get_batch_config_for_queue(queue: str) -> Dict:
    """큐별 배치 처리 설정"""
    
    configs = {
        'notification_queue:high': {
            'batch_size': 20,
            'delay': 100  # 100ms
        },
        'notification_queue:normal': {
            'batch_size': 50,
            'delay': 200  # 200ms
        },
        'notification_queue:bulk': {
            'batch_size': 100,
            'delay': 300  # 300ms
        }
    }
    
    return configs.get(queue, {
        'batch_size': 50,
        'delay': 200
    })

def process_notification_batch(notifications: List[Dict]) -> Dict:
    """알림 배치 처리 (RDS 기록 포함)"""
    
    try:
        # Expo 클라이언트로 배치 발송
        result = send_immediate_notifications(notifications)
        
        print(f"Batch result: {result['success']} success, {len(result['errors'])} errors")
        
        # RDS에 결과 기록
        try:
            # 성공한 알림들 기록
            if result['success'] > 0:
                success_notifications = []
                error_count = len(result.get('errors', []))
                success_count = result['success']
                
                # 성공한 알림들 추출 (에러가 없는 알림들)
                if error_count < len(notifications):
                    # 에러가 있는 알림의 토큰들 수집
                    error_tokens = set()
                    for error in result.get('errors', []):
                        if 'token' in error:
                            error_tokens.add(error['token'])
                    
                    # 에러가 없는 알림들 = 성공한 알림들
                    for notification in notifications:
                        if notification.get('token') not in error_tokens:
                            record_notification_success(notification, result)
            
            # 실패한 알림들 기록
            for error in result.get('errors', []):
                error_notification = next(
                    (n for n in notifications if n.get('token') == error.get('token')), 
                    error.get('notification', {})
                )
                record_notification_failure(error_notification, error.get('error', 'Unknown error'))
                
        except Exception as rds_error:
            print(f"RDS recording failed: {rds_error}")
            # RDS 실패해도 메인 로직에는 영향 없음
        
        return result
        
    except Exception as e:
        print(f"Batch processing failed: {e}")
        
        # 모든 알림을 실패로 기록
        try:
            for notification in notifications:
                record_notification_failure(notification, str(e))
        except Exception as rds_error:
            print(f"RDS failure recording failed: {rds_error}")
        
        return {
            'success': 0,
            'errors': [{'error': str(e), 'notifications': notifications}]
        }

def handle_failed_notifications(failed_notifications: List[Dict], original_queue: str):
   """실패한 알림들 재시도 처리"""
   
   if not failed_notifications:
       return
   
   valkey = ValkeyClient.get_client()
   retry_queue = f"{original_queue}:retry"
   # DLQ 비활성화
   # dlq = f"{original_queue}:dlq"
   
   for failed_item in failed_notifications:
       if 'notifications' in failed_item:
           # 배치 실패의 경우
           notifications = failed_item['notifications']
       else:
           # 개별 실패의 경우
           notifications = [failed_item]
       
       for notification in notifications:
           attempts = notification.get('attempts', 0) + 1
           max_retries = 3
           
           if attempts <= max_retries:
               # 재시도 큐에 추가
               notification['attempts'] = attempts
               notification['lastError'] = failed_item.get('error', 'Unknown error')
               notification['retryAt'] = int(time.time() + (2 ** attempts) * 60)  # 지수 백오프
               
               # RDS에 재시도 기록
               try:
                   record_notification_retry(notification, attempts)
               except Exception as rds_error:
                   print(f"RDS retry recording failed: {rds_error}")
               
               valkey.lpush(retry_queue, json.dumps(notification))
               print(f"Added to retry queue (attempt {attempts}): {notification.get('userId')}")
           else:
               # 최대 재시도 초과시 - DLQ 비활성화로 로그만 남김
               notification['finalError'] = failed_item.get('error')
               notification['failedAt'] = int(time.time())
               
               # DLQ 기능 비활성화 - 로그만 남김
               print(f"DLQ disabled: Would add to DLQ after {attempts} attempts: {notification.get('userId')}")
               print(f"Final failure for user {notification.get('userId')}: {failed_item.get('error')}")
               
               # 알람 발송 비활성화
               # send_dlq_alert(notification)

def requeue_notifications(notifications: List[Dict], queue: str):
   """알림들을 큐에 다시 추가"""
   valkey = ValkeyClient.get_client()
   
   pipe = valkey.pipeline()
   for notification in notifications:
       pipe.lpush(queue, json.dumps(notification))
   pipe.execute()
   
   print(f"Requeued {len(notifications)} notifications")

def trigger_next_worker(queue: str):
   """다음 Worker 호출"""
   
   worker_function_name = os.environ.get(
       'WORKER_FUNCTION_NAME',
       context.function_name if 'context' in globals() else 'notification-worker'
   )
   
   payload = {
       'queue': queue,
       'priority': queue.split(':')[-1] if ':' in queue else 'normal',
       'triggerReason': 'continuation',
       'triggeredAt': int(time.time())
   }
   
   try:
       lambda_client.invoke(
           FunctionName=worker_function_name,
           InvocationType='Event',
           Payload=json.dumps(payload)
       )
       print("Next worker triggered successfully")
   except Exception as e:
       print(f"Failed to trigger next worker: {e}")

# DLQ 알람 기능 - SNS 미사용으로 주석 처리
def send_dlq_alert(notification: Dict):
   """DLQ 알람 발송 - 현재 비활성화"""
   # SNS를 사용하지 않으므로 DLQ 알람 기능 비활성화
   print(f"DLQ alert disabled: Would send alert for user {notification.get('userId')}")
   return
   
   # try:
   #     sns = boto3.client('sns')
   #     topic_arn = os.environ.get('ERROR_ALERT_TOPIC_ARN')
   #     
   #     if topic_arn:
   #         message = {
   #             'alert': 'Notification processing failed',
   #             'userId': notification.get('userId'),
   #             'token': notification.get('token', '')[:20] + '...',
   #             'error': notification.get('finalError'),
   #             'attempts': notification.get('attempts')
   #         }
   #         
   #         sns.publish(
   #             TopicArn=topic_arn,
   #             Message=json.dumps(message),
   #             Subject='Notification System DLQ Alert'
   #         )
   # except Exception as e:
   #     print(f"Failed to send DLQ alert: {e}")

def send_metric(metric_name: str, value: float):
   """CloudWatch 메트릭 전송"""
   try:
       cloudwatch.put_metric_data(
           Namespace='NotificationSystem',
           MetricData=[{
               'MetricName': metric_name,
               'Value': value,
               'Unit': 'Count',
               'Timestamp': time.time()
           }]
       )
   except Exception as e:
       print(f"Failed to send metric {metric_name}: {e}")

def process_notification_batch_with_retry(notifications: List[Dict]) -> Dict:
    """개별 알림별 3회 재시도가 적용된 배치 처리"""
    
    from utils.expo_client import ExpoClient
    
    success_count = 0
    failed_count = 0
    results = []
    
    expo_client = ExpoClient()
    
    for notification in notifications:
        success = False
        max_attempts = 3
        last_error = None
        
        for attempt in range(max_attempts):
            try:
                # 개별 알림 전송
                result = expo_client.send_notifications([notification])
                
                if result['success'] > 0:
                    success_count += 1
                    success = True
                    print(f"✅ Notification sent successfully (attempt {attempt + 1}): user {notification.get('userId')}")
                    break
                else:
                    # 전송 실패 - 에러 분석
                    error_info = result['errors'][0] if result['errors'] else {'error': 'Unknown error'}
                    last_error = error_info['error']
                    
                    # 재시도 불가능한 에러인지 확인
                    if is_permanent_error(error_info):
                        print(f"❌ Permanent error, no retry: {last_error}")
                        break
                    
                    if attempt < max_attempts - 1:
                        wait_time = 2 ** attempt  # 1초, 2초, 4초
                        print(f"⚠️ Retry {attempt + 1}/{max_attempts} in {wait_time}s: {last_error}")
                        time.sleep(wait_time)
                    
            except Exception as e:
                last_error = str(e)
                if attempt < max_attempts - 1:
                    wait_time = 2 ** attempt
                    print(f"🔄 Exception retry {attempt + 1}/{max_attempts} in {wait_time}s: {last_error}")
                    time.sleep(wait_time)
        
        # 최종 실패 처리
        if not success:
            failed_count += 1
            print(f"❌ Final failure after {max_attempts} attempts: user {notification.get('userId')}")
            
            # valkey_client의 재시도 큐로 이동
            requeue_failed_notification(notification, f"expo_send_failed: {last_error}")
    
    return {
        'success': success_count,
        'failed': failed_count,
        'total': len(notifications)
    }

def is_permanent_error(error_info: Dict) -> bool:
    """재시도 불가능한 영구 에러인지 판단"""
    
    error_code = error_info.get('details', {}).get('error', '')
    error_message = error_info.get('error', '').lower()
    
    # Expo 영구 에러 코드들
    permanent_errors = [
        'DeviceNotRegistered',
        'InvalidCredentials', 
        'MessageTooBig',
        'InvalidRequest'
    ]
    
    # 영구 에러 메시지 패턴
    permanent_patterns = [
        'invalid token',
        'malformed',
        'not a valid expo push token'
    ]
    
    if error_code in permanent_errors:
        return True
    
    for pattern in permanent_patterns:
        if pattern in error_message:
            return True
    
    return False

# 전역 변수 (Lambda 컨테이너 재사용시 유지)
context = None

# 람다 실행시 컨텍스트 저장
def lambda_handler_main(event, lambda_context):
   global context
   context = lambda_context
   return lambda_handler(event, lambda_context)