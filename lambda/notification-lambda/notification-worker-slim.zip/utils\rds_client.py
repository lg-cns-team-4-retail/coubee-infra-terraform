import os
import json
import time
from typing import Optional, Dict, List, Any

# psycopg2 import with safe fallback - NO EXTENSIONS REFERENCE
PSYCOPG2_AVAILABLE = False
psycopg2 = None

try:
    import psycopg2
    import psycopg2.extras
    PSYCOPG2_AVAILABLE = True
    print("psycopg2 loaded successfully")
except ImportError as e:
    print(f"psycopg2 not available: {e}")

# Use Any type for all connection hints to avoid extensions reference
from typing import Any
ConnectionType = Any

class RDSClient:
    """RDS 연결 및 알림 기록 클라이언트"""
    
    _instance: Optional['RDSClient'] = None
    _connection: Optional[ConnectionType] = None
    
    def __init__(self):
        self._connection_config = None
    
    @classmethod
    def get_instance(cls) -> 'RDSClient':
        """싱글톤 인스턴스 반환"""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
    
    def is_enabled(self) -> bool:
        """RDS 로깅이 활성화되어 있는지 확인"""
        if not PSYCOPG2_AVAILABLE:
            print("RDS disabled: psycopg2 not available")
            return False
        return os.environ.get('RDS_ENABLED', 'false').lower() == 'true'
    
    def _get_connection_config(self) -> Dict[str, Any]:
        """환경변수에서 RDS 연결 정보 가져오기"""
        if self._connection_config is not None:
            return self._connection_config
        
        if not self.is_enabled():
            return {}
        
        try:
            # 환경변수에서 직접 연결 정보 가져오기
            host_with_port = os.environ.get('DB_HOST', '')
            database = os.environ.get('DB_NAME', '')
            username = os.environ.get('DB_USER', '')
            password = os.environ.get('DB_PASSWORD', '')
            
            # 필수 값들 확인
            if not all([host_with_port, database, username, password]):
                missing = []
                if not host_with_port: missing.append('DB_HOST')
                if not database: missing.append('DB_NAME')
                if not username: missing.append('DB_USER')
                if not password: missing.append('DB_PASSWORD')
                print(f"Missing RDS environment variables: {missing}")
                return {}
            
            # DB_HOST에서 호스트와 포트 분리 (host:port 형식)
            if ':' in host_with_port:
                host, port_str = host_with_port.rsplit(':', 1)
                try:
                    port = int(port_str)
                except ValueError:
                    print(f"Invalid port in DB_HOST: {port_str}, using default 5432")
                    host = host_with_port
                    port = 5432
            else:
                host = host_with_port
                port = 5432
            
            # 연결 설정 구성 (PostgreSQL)
            self._connection_config = {
                'host': host,
                'port': port,
                'database': database,
                'user': username,
                'password': password,
                'connect_timeout': 10,
                'sslmode': 'require'
            }
            
            print(f"RDS connection config loaded: {host}:{port}/{database}")
            return self._connection_config
            
        except Exception as e:
            print(f"Error loading RDS connection config: {e}")
            return {}
    
    def _get_connection(self) -> Optional[ConnectionType]:
        """RDS 연결 가져오기 (재사용)"""
        if not self.is_enabled():
            return None
        
        try:
            # 기존 연결이 유효한지 확인
            if self._connection is not None and not self._connection.closed:
                # 간단한 쿼리로 연결 상태 확인
                with self._connection.cursor() as cursor:
                    cursor.execute("SELECT 1")
                return self._connection
                
        except:
            # 연결이 끊어진 경우 새로 연결
            self._connection = None
        
        # 새 연결 생성
        config = self._get_connection_config()
        if not config or not config.get('host'):
            return None
        
        try:
            self._connection = psycopg2.connect(**config)
            self._connection.autocommit = True
            print("RDS connection established")
            return self._connection
            
        except Exception as e:
            print(f"Failed to connect to RDS: {e}")
            return None
    
    def close_connection(self):
        """연결 종료"""
        if self._connection:
            try:
                self._connection.close()
            except:
                pass
            finally:
                self._connection = None
    
    def record_notification_result(self, notification_data: Dict[str, Any]) -> bool:
        """알림 전송 결과 기록"""
        if not self.is_enabled():
            print("RDS logging is disabled (RDS_ENABLED=false or not set)")
            return True  # RDS 비활성화 시 성공으로 처리
        
        connection = self._get_connection()
        if not connection:
            print("RDS connection not available, skipping record")
            return False
        
        try:
            with connection.cursor() as cursor:
                # 알림 기록 테이블에 삽입 (PostgreSQL)
                sql = """
                INSERT INTO coubee_notification.notification_logs (
                    user_id, message_type, token,
                    title, body, data_json, status, error_message,
                    sent_at, created_at
                ) VALUES (
                    %s, %s, %s,
                    %s, %s, %s, %s, %s,
                    to_timestamp(%s), NOW()
                )
                """
                
                # 데이터 준비
                data = (
                    notification_data.get('userId', ''),
                    notification_data.get('messageType', ''),
                    notification_data.get('token', ''),
                    notification_data.get('title', ''),
                    notification_data.get('body', ''),
                    json.dumps(notification_data.get('data', {})),
                    notification_data.get('status', 'unknown'),
                    notification_data.get('error', None),
                    notification_data.get('sentAt', time.time())
                )
                
                cursor.execute(sql, data)
                return True
                
        except Exception as e:
            print(f"Failed to record notification result: {e}")
            return False
    
    def record_batch_results(self, results: List[Dict[str, Any]]) -> int:
        """알림 배치 결과 기록"""
        if not self.is_enabled() or not results:
            return len(results) if results else 0
        
        success_count = 0
        for result in results:
            if self.record_notification_result(result):
                success_count += 1
        
        return success_count
    
    def get_notification_stats(self, user_id: str = None, hours: int = 24) -> Dict[str, int]:
        """알림 통계 조회"""
        if not self.is_enabled():
            return {}
        
        connection = self._get_connection()
        if not connection:
            return {}
        
        try:
            with connection.cursor() as cursor:
                where_clause = "WHERE created_at >= NOW() - INTERVAL '%s hours'"
                params = [hours]
                
                if user_id:
                    where_clause += " AND user_id = %s"
                    params.append(user_id)
                
                sql = f"""
                SELECT 
                    status,
                    COUNT(*) as count
                FROM coubee_notification.notification_logs 
                {where_clause}
                GROUP BY status
                """
                
                cursor.execute(sql, params)
                results = cursor.fetchall()
                
                return {row[0]: row[1] for row in results}
                
        except Exception as e:
            print(f"Failed to get notification stats: {e}")
            return {}

def get_rds_client() -> RDSClient:
    """RDS 클라이언트 인스턴스 반환"""
    return RDSClient.get_instance()

def record_notification_success(notification: Dict[str, Any], response_data: Dict = None):
    """성공한 알림 기록"""
    try:
        if not PSYCOPG2_AVAILABLE:
            print("RDS logging skipped: psycopg2 not available (likely Windows binary issue)")
            return
            
        client = get_rds_client()
        if not client.is_enabled():
            print("RDS logging disabled")
            return
        
        record_data = {
            **notification,
            'status': 'success',
            'sentAt': time.time()
        }
        
        if response_data:
            record_data['expo_response'] = response_data
        
        success = client.record_notification_result(record_data)
        if success:
            print("✓ RDS logging successful")
        else:
            print("✗ RDS logging failed")
        
    except Exception as e:
        print(f"Failed to record notification success: {e}")
        # 상세한 에러 정보는 디버그 모드에서만
        if os.environ.get('DEBUG', 'false').lower() == 'true':
            import traceback
            print(f"Full traceback: {traceback.format_exc()}")

def record_notification_failure(notification: Dict[str, Any], error: str):
    """실패한 알림 기록"""
    try:
        client = get_rds_client()
        
        record_data = {
            **notification,
            'status': 'failure',
            'error': str(error),
            'sentAt': time.time()
        }
        
        client.record_notification_result(record_data)
        
    except Exception as e:
        print(f"Failed to record notification failure: {e}")

def record_notification_retry(notification: Dict[str, Any], attempt: int):
    """재시도한 알림 기록"""
    try:
        client = get_rds_client()
        
        record_data = {
            **notification,
            'status': 'retry',
            'attempt': attempt,
            'sentAt': time.time()
        }
        
        client.record_notification_result(record_data)
        
    except Exception as e:
        print(f"Failed to record notification retry: {e}")